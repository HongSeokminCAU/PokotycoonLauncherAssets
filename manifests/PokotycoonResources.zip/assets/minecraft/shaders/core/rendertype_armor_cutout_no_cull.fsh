#version 150
#moj_import <fog.glsl>
uniform sampler2D Sampler0;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
in float vertexDistance;
in vec4 vertexColor;
in vec4 untintedVertexColor;
flat in vec4 armorTint;
in vec2 texCoord0;
in vec2 texCoord1;
out vec4 fragColor;
void main() {
    vec2 uv = texCoord0;
    vec4 lighting = vertexColor;
    bool atlas = all(equal(textureSize(Sampler0, 0), ivec2(2048,896)));
    // Base dye and the always-white vanilla overlay are different draw passes.
    // Keep overlay UVs on tile 0, including when a costume reserves pure white.
    bool overlayAtlas = false;
    if (atlas) {
        vec4 atlasMarker = texelFetch(Sampler0, ivec2(2047,0), 0);
        overlayAtlas = distance(atlasMarker, vec4(211,137,59,255)/255.0) < 0.002;
        atlas = overlayAtlas || distance(atlasMarker, vec4(59,137,211,255)/255.0) < 0.002;
    }
    if (atlas) {
        uv /= vec2(8.0, 7.0);
        float tile = 0.0;
        if (!overlayAtlas) {
        if (distance(armorTint.rgb, vec3(253,193,48)/255.0) < 0.001) tile = 1.0;
        if (distance(armorTint.rgb, vec3(253,209,64)/255.0) < 0.001) tile = 2.0;
        if (distance(armorTint.rgb, vec3(184,225,247)/255.0) < 0.001) tile = 3.0;
        if (distance(armorTint.rgb, vec3(246,168,77)/255.0) < 0.001) tile = 4.0;
        if (distance(armorTint.rgb, vec3(121,83,201)/255.0) < 0.001) tile = 5.0;
        if (distance(armorTint.rgb, vec3(201,63,74)/255.0) < 0.001) tile = 6.0;
        if (distance(armorTint.rgb, vec3(237,161,47)/255.0) < 0.001) tile = 7.0;
        if (distance(armorTint.rgb, vec3(64,137,181)/255.0) < 0.001) tile = 8.0;
        if (distance(armorTint.rgb, vec3(102,41,68)/255.0) < 0.001) tile = 9.0;
        if (distance(armorTint.rgb, vec3(210,179,140)/255.0) < 0.001) tile = 10.0;
        if (distance(armorTint.rgb, vec3(216,117,145)/255.0) < 0.001) tile = 11.0;
        if (distance(armorTint.rgb, vec3(121,81,58)/255.0) < 0.001) tile = 12.0;
        if (distance(armorTint.rgb, vec3(47,41,57)/255.0) < 0.001) tile = 13.0;
        if (distance(armorTint.rgb, vec3(199,97,33)/255.0) < 0.001) tile = 14.0;
        if (distance(armorTint.rgb, vec3(79,47,140)/255.0) < 0.001) tile = 15.0;
        if (distance(armorTint.rgb, vec3(226,219,244)/255.0) < 0.001) tile = 16.0;
        if (distance(armorTint.rgb, vec3(90,51,34)/255.0) < 0.001) tile = 17.0;
        if (distance(armorTint.rgb, vec3(93,46,30)/255.0) < 0.001) tile = 18.0;
        if (distance(armorTint.rgb, vec3(177,77,32)/255.0) < 0.001) tile = 19.0;
        if (distance(armorTint.rgb, vec3(51,45,62)/255.0) < 0.001) tile = 20.0;
        if (distance(armorTint.rgb, vec3(249,216,74)/255.0) < 0.001) tile = 21.0;
        if (distance(armorTint.rgb, vec3(84,42,26)/255.0) < 0.001) tile = 22.0;
        if (distance(armorTint.rgb, vec3(221,178,234)/255.0) < 0.001) tile = 23.0;
        if (distance(armorTint.rgb, vec3(33,56,119)/255.0) < 0.001) tile = 24.0;
        if (distance(armorTint.rgb, vec3(32,54,118)/255.0) < 0.001) tile = 25.0;
        if (distance(armorTint.rgb, vec3(220,171,40)/255.0) < 0.001) tile = 26.0;
        if (distance(armorTint.rgb, vec3(242,138,60)/255.0) < 0.001) tile = 27.0;
        if (distance(armorTint.rgb, vec3(94,65,40)/255.0) < 0.001) tile = 28.0;
        if (distance(armorTint.rgb, vec3(58,56,73)/255.0) < 0.001) tile = 29.0;
        if (distance(armorTint.rgb, vec3(255,244,239)/255.0) < 0.001) tile = 30.0;
        if (distance(armorTint.rgb, vec3(245,138,58)/255.0) < 0.001) tile = 31.0;
        if (distance(armorTint.rgb, vec3(248,176,196)/255.0) < 0.001) tile = 32.0;
        if (distance(armorTint.rgb, vec3(240,162,60)/255.0) < 0.001) tile = 33.0;
        if (distance(armorTint.rgb, vec3(198,90,53)/255.0) < 0.001) tile = 34.0;
        if (distance(armorTint.rgb, vec3(95,189,230)/255.0) < 0.001) tile = 35.0;
        if (distance(armorTint.rgb, vec3(32,36,99)/255.0) < 0.001) tile = 36.0;
        if (distance(armorTint.rgb, vec3(234,220,178)/255.0) < 0.001) tile = 37.0;
        if (distance(armorTint.rgb, vec3(234,220,179)/255.0) < 0.001) tile = 38.0;
        if (distance(armorTint.rgb, vec3(91,168,238)/255.0) < 0.001) tile = 39.0;
        if (distance(armorTint.rgb, vec3(123,197,236)/255.0) < 0.001) tile = 40.0;
        if (distance(armorTint.rgb, vec3(22,19,27)/255.0) < 0.001) tile = 41.0;
        if (distance(armorTint.rgb, vec3(251,248,242)/255.0) < 0.001) tile = 42.0;
        if (distance(armorTint.rgb, vec3(189,181,186)/255.0) < 0.001) tile = 43.0;
        if (distance(armorTint.rgb, vec3(247,217,122)/255.0) < 0.001) tile = 44.0;
        if (distance(armorTint.rgb, vec3(228,222,210)/255.0) < 0.001) tile = 45.0;
        if (distance(armorTint.rgb, vec3(243,228,134)/255.0) < 0.001) tile = 46.0;
        if (distance(armorTint.rgb, vec3(40,42,58)/255.0) < 0.001) tile = 47.0;
        if (distance(armorTint.rgb, vec3(168,219,108)/255.0) < 0.001) tile = 48.0;
        if (distance(armorTint.rgb, vec3(230,220,182)/255.0) < 0.001) tile = 49.0;
        if (distance(armorTint.rgb, vec3(255,255,255)/255.0) < 0.001) tile = 50.0;
        if (distance(armorTint.rgb, vec3(42,47,52)/255.0) < 0.001) tile = 51.0;
        if (distance(armorTint.rgb, vec3(58,53,50)/255.0) < 0.001) tile = 52.0;
        if (distance(armorTint.rgb, vec3(33,41,38)/255.0) < 0.001) tile = 53.0;
        }
        // Autumn boots: the vanilla leg top cap is at the hip, not the cuff.
        // Suppress only that cap for tile 12; retain soles, cuffs and every other armor.
        if (tile == 12.0 && texCoord0.x >= 4.0 / 64.0 && texCoord0.x < 8.0 / 64.0
            && texCoord0.y >= 16.0 / 32.0 && texCoord0.y < 20.0 / 32.0) discard;
        if (tile > 0.0) { uv += vec2(mod(tile, 8.0), floor(tile / 8.0)) / vec2(8.0, 7.0); lighting = untintedVertexColor; }
        // Vanilla overlay stays intact. Custom opaque base is lifted in the vertex stage.
    }
    vec4 result = texture(Sampler0, uv) * lighting * ColorModulator;
    if (result.a < 0.1) discard;
    fragColor = linear_fog(result, vertexDistance, FogStart, FogEnd, FogColor);
}

