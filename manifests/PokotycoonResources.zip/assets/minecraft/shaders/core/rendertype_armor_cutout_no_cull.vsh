#version 150
#moj_import <light.glsl>
#moj_import <fog.glsl>
in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;
uniform sampler2D Sampler2;
uniform sampler2D Sampler0;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
out float vertexDistance;
out vec4 vertexColor;
out vec4 untintedVertexColor;
flat out vec4 armorTint;
out vec2 texCoord0;
out vec2 texCoord1;
void main() {
    // Lift ONLY the selected opaque custom base a tiny amount above vanilla overlay.
    // White overlay and every ordinary armor draw remain untouched.
    vec3 armorPosition = Position;
    bool customAtlas = all(equal(textureSize(Sampler0, 0), ivec2(2048,896)));
    if (customAtlas) customAtlas = distance(texelFetch(Sampler0, ivec2(2047,0), 0), vec4(59,137,211,255)/255.0) < 0.002;
    if (customAtlas && (distance(Color.rgb, vec3(253,193,48)/255.0) < 0.001 || distance(Color.rgb, vec3(253,209,64)/255.0) < 0.001 || distance(Color.rgb, vec3(184,225,247)/255.0) < 0.001 || distance(Color.rgb, vec3(246,168,77)/255.0) < 0.001 || distance(Color.rgb, vec3(121,83,201)/255.0) < 0.001 || distance(Color.rgb, vec3(201,63,74)/255.0) < 0.001 || distance(Color.rgb, vec3(237,161,47)/255.0) < 0.001 || distance(Color.rgb, vec3(64,137,181)/255.0) < 0.001 || distance(Color.rgb, vec3(102,41,68)/255.0) < 0.001 || distance(Color.rgb, vec3(210,179,140)/255.0) < 0.001 || distance(Color.rgb, vec3(216,117,145)/255.0) < 0.001 || distance(Color.rgb, vec3(121,81,58)/255.0) < 0.001 || distance(Color.rgb, vec3(47,41,57)/255.0) < 0.001 || distance(Color.rgb, vec3(199,97,33)/255.0) < 0.001 || distance(Color.rgb, vec3(79,47,140)/255.0) < 0.001 || distance(Color.rgb, vec3(226,219,244)/255.0) < 0.001 || distance(Color.rgb, vec3(90,51,34)/255.0) < 0.001 || distance(Color.rgb, vec3(93,46,30)/255.0) < 0.001 || distance(Color.rgb, vec3(177,77,32)/255.0) < 0.001 || distance(Color.rgb, vec3(51,45,62)/255.0) < 0.001 || distance(Color.rgb, vec3(249,216,74)/255.0) < 0.001 || distance(Color.rgb, vec3(84,42,26)/255.0) < 0.001 || distance(Color.rgb, vec3(221,178,234)/255.0) < 0.001 || distance(Color.rgb, vec3(33,56,119)/255.0) < 0.001 || distance(Color.rgb, vec3(32,54,118)/255.0) < 0.001 || distance(Color.rgb, vec3(220,171,40)/255.0) < 0.001 || distance(Color.rgb, vec3(242,138,60)/255.0) < 0.001 || distance(Color.rgb, vec3(94,65,40)/255.0) < 0.001 || distance(Color.rgb, vec3(58,56,73)/255.0) < 0.001 || distance(Color.rgb, vec3(255,244,239)/255.0) < 0.001 || distance(Color.rgb, vec3(245,138,58)/255.0) < 0.001 || distance(Color.rgb, vec3(248,176,196)/255.0) < 0.001 || distance(Color.rgb, vec3(240,162,60)/255.0) < 0.001 || distance(Color.rgb, vec3(198,90,53)/255.0) < 0.001 || distance(Color.rgb, vec3(95,189,230)/255.0) < 0.001 || distance(Color.rgb, vec3(32,36,99)/255.0) < 0.001 || distance(Color.rgb, vec3(234,220,178)/255.0) < 0.001 || distance(Color.rgb, vec3(234,220,179)/255.0) < 0.001 || distance(Color.rgb, vec3(91,168,238)/255.0) < 0.001 || distance(Color.rgb, vec3(123,197,236)/255.0) < 0.001 || distance(Color.rgb, vec3(22,19,27)/255.0) < 0.001 || distance(Color.rgb, vec3(251,248,242)/255.0) < 0.001 || distance(Color.rgb, vec3(189,181,186)/255.0) < 0.001 || distance(Color.rgb, vec3(247,217,122)/255.0) < 0.001 || distance(Color.rgb, vec3(228,222,210)/255.0) < 0.001 || distance(Color.rgb, vec3(243,228,134)/255.0) < 0.001 || distance(Color.rgb, vec3(40,42,58)/255.0) < 0.001 || distance(Color.rgb, vec3(168,219,108)/255.0) < 0.001 || distance(Color.rgb, vec3(230,220,182)/255.0) < 0.001 || distance(Color.rgb, vec3(255,255,255)/255.0) < 0.001)) armorPosition += Normal * 0.001;
    gl_Position = ProjMat * ModelViewMat * vec4(armorPosition, 1.0);
    vertexDistance = fog_distance(Position, FogShape);
    vec4 lightmap = texelFetch(Sampler2, UV2 / 16, 0);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * lightmap;
    untintedVertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, vec4(1)) * lightmap;
    armorTint = Color;
    texCoord0 = UV0;
    texCoord1 = UV1;
}

