// BetterHud 1.14 emits this import for newer overlays.
// Minecraft 1.21.1 resolves imports before evaluating SHADER_VERSION,
// so a harmless compatibility stub is required for the legacy shader path.
